/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;

import java.util.ArrayDeque;

/**
 *
 * @author Sangeetha Detne
 */
public class AStack <E> {
    
    private ArrayDeque<E> myStack;

    public AStack() {
        this.myStack = new ArrayDeque<>();
    }
    public void push(E element)
    {
        myStack.add(element);
    }
    public E pop()
    {
        return myStack.removeLast();
    }
    public E peek()
    {
        return myStack.getLast();
    }
    public int size()
    {
        return myStack.size();
    }
    public boolean isEmpty()
    {
        if(myStack.size()==0)
            return false;
        else
            return true;
    }
}
