/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class BalancedParens {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        Scanner scr = new Scanner(new File("expressions.txt"));
        while (scr.hasNext()) {
            AStack<Character> parentStack = new AStack();
            String expr = scr.nextLine();
            int parentCount0 = 0;
            String errorMessage = null;
            for (int i = 0; i < expr.length(); i++) {
                if (expr.charAt(i) == '(') {
                    parentCount0++;
                } else if (expr.charAt(i) == ')') {
                    parentCount0--;
                }
            }

            char[] chrcter = expr.toCharArray();
            for (int i = 0; i < chrcter.length; i++) {
                if (chrcter[i] == '(') {
                    parentStack.push(chrcter[i]);
                } else if (chrcter[i] == ')') {
                    try {
                        parentStack.pop();
                    } catch (NoSuchElementException ex) {
                        errorMessage = expr + ": INVALID:\n"
                                + "Trying to pop, but the stack is empty!";
                    }
                }
            }

            if (errorMessage != null) {
                System.out.println(errorMessage);
            } else if (parentStack.isEmpty()) {
                System.out.println(expr + ": VALID");
            } else {
                System.out.println(expr + ": INVALID:\n" + "Parsing complete, "
                        + "but the stack is not empty!");

            }
            System.out.println("");
        }
    }

}
