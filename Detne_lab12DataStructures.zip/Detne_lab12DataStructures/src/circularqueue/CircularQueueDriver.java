/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circularqueue;

/**
 *
 * @author Sangeetha Detne
 */
public class CircularQueueDriver {
    
   
    public static void main(String[] args)  {
        // TODO code application logic here

        CircularQueue<Integer> cirQueue = new CircularQueue(50);

        System.out.println("*******************************************\n"
                + "Circular Queue\n"
                + "*******************************************");
        
        try{
        cirQueue.insert(20);
        cirQueue.insert(23);
        cirQueue.insert(22);
        cirQueue.insert(1);
        cirQueue.insert(3);
        cirQueue.insert(4);
        cirQueue.insert(6);
        cirQueue.insert(8);
        cirQueue.insert(5);
        cirQueue.insert(15);
        cirQueue.insert(14);
        cirQueue.insert(9);
        cirQueue.insert(12);
        cirQueue.insert(87);
        cirQueue.insert(13);
        cirQueue.insert(34);
        cirQueue.insert(83);
        cirQueue.insert(17);
        cirQueue.insert(18);
        cirQueue.insert(19);
        }
        catch(QueueFullException e){
            System.out.println(e.getMessage());
        }
        System.out.println("Length of the circular queue is:");
        System.out.println("The length of the queue is " + cirQueue.length());
        System.out.println("Queue Elements:\n"
                + cirQueue.print(cirQueue.length() - 1));
        System.out.println("Removing element from circular queue");
        System.out.println("Length of queue after removal");
        try{
        cirQueue.remove();
        }
        catch(QueueEmptyException e1){
            System.out.println(e1.getMessage());
        }
        System.out.println("The length of the queue is " + cirQueue.length());
        System.out.println("Element removed");
    }
    
}
