/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circularqueue;

/**
 *
 * @author Sangeetha Detne
 */
public class CircularQueue<E> {
    
        private int currentSize; //Current Circular Queue Size
        private E[] circularQueue;
        private int maxSize; //Circular Queue maximum size

        private int rear; //rear position of Circular queue(new element added at rear).
        private int front; //front position of Circular queue(element will be removed from front).      

        public CircularQueue(int maxSize) {
            this.maxSize = maxSize;
            circularQueue = (E[]) new Object[this.maxSize];
            currentSize = 0;
            front = 0;
            rear = 0;
        }

        /**
         * Add elements to rear for the queue.
         */
        public void insert(E item) throws QueueFullException {
            if (isFull()) {
                throw new QueueFullException("Circular Queue is full. Element cannot be added");
            } else {
                circularQueue[rear] = item;
                rear = (rear + 1) % circularQueue.length;
                currentSize++;
            }
        }

        /**
         * Remove element from Front of the queue.
         */
        public void remove() throws QueueEmptyException {
            E removedElement;
            if (isEmpty()) {
                throw new QueueEmptyException("Circular Queue is empty.");
            } else {
                removedElement = circularQueue[front];
                circularQueue[front] = null;
                front = (front + 1) % circularQueue.length;
                currentSize--;
            }
        }

        /**
         * Checking whether queue is full.
         */
        public boolean isFull() {
            return (currentSize == circularQueue.length);
        }

        /**
         * Check whether Queue is empty.
         */
        public boolean isEmpty() {
            return (currentSize == 0);
        }

        /*
        knowing the length of the queue
        */
        public int length() {
            return currentSize;
        }

        public E retrieve() {
            return circularQueue[front];
        }

        /*
        printing the elements from the queue
        */
        public String print(int pos) {
            String output = "";

            if (pos == 0) {
                output = circularQueue[pos] + output;
            } else if (pos >= 1) {
                output = print(pos - 1) + "\n" + circularQueue[pos] + output;
            }
            return output;
        }

    }


