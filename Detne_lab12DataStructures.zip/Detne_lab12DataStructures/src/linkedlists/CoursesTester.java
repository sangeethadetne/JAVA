/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlists;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author  Sangeetha Detne
 */
public class CoursesTester {
    
        public static void main(String[] args) throws FileNotFoundException {
        Detne_ALinkedList<Course> courses0 = new Detne_ALinkedList<>();
        String courseID;
        String courseName;
        int credHrs;

        Scanner in = new Scanner(new File("courses.txt"));

        while (in.hasNext()) {
            courseID = in.nextLine();
            courseName = in.nextLine();
            credHrs = in.nextInt();
            courses0.addFirst(new Course(courseID, courseName, credHrs));
            if (in.hasNext()) {
                in.nextLine();
            }
        }
        System.out.println(courses0);
        System.out.println(courses0.size() + " courses in the list");
        System.out.println("deleting " + courses0.removeFirst());
        System.out.println(courses0.size() + " courses in the list");
    }
    
}
