/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlists;

/**
 *
 * @author Sangeetha Detne
 */
public class Tester {

   
    public static void main(String[] args) {
        // TODO code application logic here
        
        Detne_ALinkedList<Integer> LinkLst = new Detne_ALinkedList<>();

        LinkLst.addFirst(17);
        LinkLst.addFirst(25);
        LinkLst.addFirst(47);
        LinkLst.removeFirst();
        LinkLst.addFirst(55);

        System.out.println("Contents of linked list\n"
                + (LinkLst.isEmpty() ? "list is empty" : LinkLst));

        while (!LinkLst.isEmpty()) {
            System.out.println("Deleting " + LinkLst.removeFirst());
        }
        System.out.println();
        System.out.println("Contents of linked list\n"
                + (LinkLst.isEmpty() ? "list is empty" : LinkLst));
    
    }
    
}
