/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class HospitalDriver {
    
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        Scanner sc = new Scanner(new File("input.txt"));

            String docName, SpecialityType, officeHours, hospitalName, hospitalAddress;

            AbstractHospitalInfo hospitalInfo = new OutPatient();

            hospitalName = sc.nextLine();
            hospitalAddress = sc.nextLine();
            System.out.println("****************************************\n"
                    + "Patient Details: ");
            while (sc.hasNext()) {

                String nextToken = sc.nextLine();
                if (nextToken.equals("Doctor")) {
                    docName = sc.nextLine();
                    SpecialityType = sc.nextLine();
                    officeHours = sc.nextLine();

                    Doctor doctor = new Doctor(docName, officeHours, SpecialityType);
                    try {
                        hospitalInfo.addDoctors(doctor);
                    } catch (InvalidDoctorSizeException ex) {

                    }
                } else {
                    char gender = nextToken.charAt(0);
                    int age = Integer.parseInt(sc.nextLine());
                    String firstName = sc.nextLine();
                    String lastName = sc.nextLine();
                    int insuranceID = Integer.parseInt(sc.nextLine());
                    String doctorToVisit = sc.nextLine();

                    Patient patient = new Patient(firstName, lastName, insuranceID, age, gender, doctorToVisit);
                    OutPatient outPatient = new OutPatient(hospitalName, hospitalAddress, patient);
                    System.out.println("****************************************");
                    System.out.println(outPatient.toString());

                    hospitalInfo.assignPatientsToDoctor(hospitalInfo.getAvailableDoctorsList(), patient);

                    String billingDetails = sc.nextLine();

                    double billGenerated = outPatient.calcBill(billingDetails);
                    System.out.println("Bill Amount Generated before Insurance deduction:"
                            + billGenerated);

                    String insuranceCompany = sc.nextLine();
                    double insuranceCoverage = Double.parseDouble(sc.nextLine());
                    if (age < 16) {

                        ChildInsurance childInsurance = new ChildInsurance(insuranceCompany,
                                insuranceCoverage, firstName, lastName, insuranceID,
                                age, gender, doctorToVisit);

                        System.out.println(childInsurance.toString());
                        try {
                            String insurancePlanName = childInsurance.checkHealthInsurancePlan();
                            System.out.println("Insurance Plan Name: " + insurancePlanName);
                        } catch (InvalidInsuranceIDException ex) {

                        }
                        double premiumPaid = Double.parseDouble(sc.nextLine());
                        try {
                            double amountPayable = childInsurance.calcAmountPayableToHospital(premiumPaid, billGenerated);
                            System.out.println("Amount to be paid by after insurance deduction: "
                                    + amountPayable);
                        } catch (NegativeAmountException ex) {
                            System.out.println(ex);
                        }
                        System.out.println("****************************************");
                    } else {

                        AdultInsurance adultInsurance = new AdultInsurance(insuranceCompany,
                                insuranceCoverage, firstName, lastName, insuranceID,
                                age, gender, doctorToVisit);

                        System.out.println(adultInsurance.toString());
                        try {
                            String insurancePlanName = adultInsurance.checkHealthInsurancePlan();
                            System.out.println("Insurance Plan Name: " + insurancePlanName);
                        } catch (InvalidInsuranceIDException ex) {
                            System.out.println(ex);
                        }
                        double premiumPaid = Double.parseDouble(sc.nextLine());
                        try {
                            double amountPayable = adultInsurance.calcAmountPayableToHospital(premiumPaid, billGenerated);
                            System.out.println("Amount to be paid by after insurance deduction: "
                                    + amountPayable);
                        } catch (NegativeAmountException ex) {

                        }

                    }

                }

            }
        System.out.println("");
        System.out.println("****************************************\n"
                + "Patients assigned to doctor \"Lisa DiStefano\": \n"
                + "****************************************");
        
        for(Doctor doctor: hospitalInfo.getPatientsMappedToDoctor().keySet()) {
            if (doctor.getName().equals("Lisa DiStefano")) {
                System.out.println(hospitalInfo.getPatientsMappedToDoctor().get(doctor));
            }
        }
        
        
    }
    
}
