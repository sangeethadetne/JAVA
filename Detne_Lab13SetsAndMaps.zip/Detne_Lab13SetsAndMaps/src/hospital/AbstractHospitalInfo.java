/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 *
 * @author Sangeetha Detne
 */
public abstract class AbstractHospitalInfo implements Hospital{
    
    private List<Doctor> availableDoctorsList;
    private String hospitalAddress;
    private String hospitalname;
    private HashMap<Doctor,HashSet<Patient>>patientsMappedToDoctor;
    
    public AbstractHospitalInfo()
    {
      availableDoctorsList=new ArrayList<Doctor>();  
      patientsMappedToDoctor = new HashMap<>();
    }

    public AbstractHospitalInfo(String hospitalname, String hospitalAddress) {
        this.hospitalAddress = hospitalAddress;
        this.hospitalname = hospitalname;
    }
    
   public void addDoctors(Doctor doctor)
                throws InvalidDoctorSizeException{
        if (availableDoctorsList.size()<0) {
            throw new InvalidDoctorSizeException();    
       }
       else{
         availableDoctorsList.add(doctor); 
       }  
    }

    @Override
    public void assignPatientsToDoctor(List<Doctor> doctorList, Patient patient) {
        
    }

  
    @Override
    public abstract double calcBill(String billingDetail); 

    public List<Doctor> getAvailableDoctorsList() {
        return availableDoctorsList;
    }

    public String getHospitalAddress() {
        return hospitalAddress;
    }

    public String getHospitalname() {
        return hospitalname;
    }

    public HashMap<Doctor, HashSet<Patient>> getPatientsMappedToDoctor() {
        return patientsMappedToDoctor;
    }

    public void setPatientsMappedToDoctor(HashMap<Doctor, HashSet<Patient>> patientsMappedToDoctor) {
        this.patientsMappedToDoctor = patientsMappedToDoctor;
    }

   
    public void setAvailableDoctorsList(List<Doctor> availableDoctorsList) {
        this.availableDoctorsList = availableDoctorsList;
    }
    @Override
    public String toString()
    {
      return "HospitalName: "+getHospitalname()+", HospitalAddress: "+getHospitalAddress();
    }
            

    
    
    
    
    
}
