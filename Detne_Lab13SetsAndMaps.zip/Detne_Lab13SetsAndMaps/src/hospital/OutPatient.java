/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.HashSet;
import java.util.List;

/**
 *
 * @author Sangeetha Detne
 */
public class OutPatient extends AbstractHospitalInfo {
    
    private Patient patient;

    public OutPatient() {
    }

    public OutPatient(String hospitalName, String hospitalAddress, Patient patient) {
        super(hospitalName, hospitalAddress);
        this.patient = patient;

    }

    @Override
    public void assignPatientsToDoctor(List<Doctor> doctorList,
            Patient patient) {

       for(Doctor doctor : doctorList) {
           if (doctor.getName().equals(patient.getDoctorToVisit())) {
              HashSet<Patient> patientSet = super.getPatientsMappedToDoctor().get(doctor);
           if (patientSet == null) {
              super.getPatientsMappedToDoctor().put(doctor, new HashSet());
           }
           super.getPatientsMappedToDoctor().get(doctor).add(patient);
           }
       }
        super.setPatientsMappedToDoctor(super.getPatientsMappedToDoctor());
    }

    @Override
    public double calcBill(String billingDetails) {
        double bill = 0.00;

        String[] items = billingDetails.split(",");

        for (String item : items) {
            switch (item) {
                case "Diphtheria":
                    bill = bill + 10.25;
                    break;
                case "Tetanus":
                    bill = bill + 12.99;
                    break;
                case "Acellular pertussis":
                    bill = bill + 17.89;
                    break;
                case "Haemophilus influenzae":
                    bill = bill + 7.5;
                    break;
                case "Pneumococcal conjugate":
                    bill = bill + 9.9;
                    break;
                default:
                    bill = bill + EMERGENCY_FEE;
                    break;
            }
        }
        return bill + BASE_CONSULTATION_FEE;
    }

    @Override
    public String toString() {
        return super.toString() + "\n"+patient.toString();
    }

    
}
