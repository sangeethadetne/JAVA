/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author Sangeetha Detne
 */
public abstract class AbstractInsurance extends Patient implements Insurance {

    private String InsuranceCompanyName;
    private double InsuranceCoverage;

    public AbstractInsurance(String insuranceCompanyName, double insuranceCoverage, 
            String fName, String lName, int insuranceID, int age, char gender, String doctorToVisit) {
        super(fName, lName, insuranceID, age, gender, doctorToVisit);
        this.InsuranceCompanyName = insuranceCompanyName;
        this.InsuranceCoverage = insuranceCoverage;
    }

    /**
     *
     * @param PremiumPaidByCustomer
     * @param billGenerated
     * @return
     */
    @Override
    public abstract double calcAmountPayableToHospital(double PremiumPaidByCustomer, double billGenerated)throws NegativeAmountException ;

    public String checkHealthInsurancePlan() throws InvalidInsuranceIDException {
        if (this.getInsuranceID() > 0 && getInsuranceID() < 10000) {
            return "Health maintenance organizations (HMOs) plan";
        } else if (this.getInsuranceID() > 10000 && getInsuranceID() < 20000) {
            return "Preferred provider organizations (PPOs) plan";
        } else if (getInsuranceID() > 20000 && getInsuranceID() < 30000) {
            return "Point-of-service (POS) plan";
        } else if (getInsuranceID() > 30000 && getInsuranceID() < 40000) {
            return "High-deductible health plans (HDHPs)";
        } else {
            throw new InvalidInsuranceIDException();
        }
    }

    public String getInsuranceCompanyName() {
        return InsuranceCompanyName;
    }

    public double getInsuranceCoverage() {
        return InsuranceCoverage;
    }

}
