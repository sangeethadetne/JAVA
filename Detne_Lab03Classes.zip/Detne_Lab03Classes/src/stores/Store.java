/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

/**
 *This class is used to generate concrete class and scanner class
 * @author 8.1 JDK version is used
 * @author Sangeetha Detne
 */
public class Store {
    private String storeName;
    private int storeID;
    private String phoneNumber;
    private String street;
    private String city;
    private String state;
    private int zipCode;

    /**
     *This is parameterized constructor ,these parameters are assigned to the local variables using "this" keyword
     * @param storeName // stores storeName
     * @param storeID //  stores storeID
     * @param phoneNumber// stores PhoneNumber
     * @param street//stores street
     * @param city//stores city
     * @param state//stores state
     * @param zipCode//store zipCode
     */
    public Store(String storeName, int storeID, String phoneNumber, String street, String city, String state, int zipCode) 
{
  this.storeName=storeName;
  this.storeID=storeID;
  this.phoneNumber=phoneNumber;
  this.street=street;
  this.city=city;
  this.state=state;
  this.zipCode=zipCode;
}

    /**
     *This is non-argument constructor
     */
    public Store(){}

    /**
     *This is getter method for store name and returns storeName  
     * @return
     */
    public String getStoreName() {
    return storeName;
}

    /**
     *This is setter method for store name and assigns it using "this" keyword 
     * @param storeName//store storeName
     */
    public void setStoreName(String storeName) {
    this.storeName = storeName;
}

    /**
     *This is getter method for storeID and returns storeID(int)  
     * @return
     */
    public int getStoreID() {
     return storeID;
    }

    /**
     *This is setter method for storeID and assigns it using "this" keyword
     * @param storeID//stores storeID parameter
     */
    public void setStoreID(int storeID) {
    this.storeID = storeID;
    }

    /**
     *This is getter method for PhoneNumber and returns PhoneNumber(string) 
     * @return
     */
    public String getPhoneNumber() {
    return phoneNumber;
    }

    /**
     *This is setter method for phoneNumber and assigns it using "this" keyword
     * @param phoneNumber//takes phoneNumber parameter 
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     *This is getter method for Street and returns Street 
     * @return
     */
    public String getStreet() {
        return street;
    }

    /**
     *This is setter method for street and assigns it using "this" keyword
     * @param street//takes street parameter
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     *This is getter method for City and returns City(string)
     * @return
     */
    public String getCity() {
        return city;
    }

    /**
     *This is setter method for city name and assigns it using "this" keyword
     * @param city//takes city parameter
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     *This is getter method for State and returns State(string)
     * @return
     */
    public String getState() {
        return state;
    }

    /**
     *This is setter method for state and assigns it using "this" keyword
     * @param state //takes state parameter
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     *This is getter method for ZipCode and returns ZipCode(int)
     * @return
     */
    public int getZipCode() {
        return zipCode;
    }

    /**
     *This is setter method for ZipCode and assigns it using "this" keyword
     * @param zipCode
     */
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    /**
     *This method is used to formateAddress and returns the address
     * @return
     */
    public String getFormattedAddress()
    {
        return street+"\n"+city+", "+state+"-"+zipCode+"\n";        
    }

    /**
     *This method is used to formatePhoneNumber and returns the phone number in below given format
     * @return
     */
    public String getFormattedPhoneNumber()
    {
        String s1=this.phoneNumber;
        return "("+s1.substring(0,3)+")"+s1.substring(3,6)+"-"+s1.substring(6);    
     }

    /**
     *This method replaces the old name with the newName .
     * @param oldName// string old name
     * @param newName// string new name 
     */
    public void replaceStoreName(String oldName, String newName){
        
        storeName=storeName.replace(oldName,newName);
    }

    /**
     *This method trims the string and returns the first word 
     * @return
     */
    public String getFirstWordOfStoreName()
    {
       return storeName.trim().substring(0,storeName.indexOf(" "));
    }

    /**
     *This method trims the string and returns the middle word 
     * @return
     */
    public String getMiddleWordOfStoreName()
    {
        return storeName.trim().substring(storeName.indexOf(" ")+1,storeName.lastIndexOf(" "));
    }

    /**
     *This method trims the string and returns the last word 
     * @return
     */
    public String getLatsWordOfStoreName()
    {
        return storeName.trim().substring(storeName.lastIndexOf(" ")+1);
    }
    /**
     * This toString() method is overridden and returns address according to the client's requirements
     * @return 
     */
    @Override
    public String toString() 
    {
        return storeName+ " ("+storeID+")"+"\n"+getFormattedAddress()+getFormattedPhoneNumber();
    }
       
        
}
    
