/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

import java.util.Scanner;

/**
 *
 * @author sangeetha Detne
 */
public class StoreDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         System.out.println("**********************Testing the Store Class**********************\n");
         System.out.println("******************************************************\n"+
                 "Testing the Getter methods or Accessors of Store Class"+
                 "\n******************************************************");
         Store store1=new Store("Timmy Tommy Enterprises", 1000,  "3127869900",
        "311 Jarvis Square","Chicago", "Illinois", 60018);
        System.out.println("Store Name: "+store1.getStoreName());
        System.out.println("Store ID: "+store1.getStoreID());
        System.out.println("Street of the Store: "+store1.getStreet());
        System.out.println("City of the Store : "+store1.getCity());
        System.out.println("State of the Store: "+store1.getState());
        System.out.println("Zip code of the Store: "+store1.getZipCode());
        System.out.println("Phone number of the Store: "+store1.getPhoneNumber());
        System.out.println("\n"+"*****************************************"+
                 "\n"+"Testing the toString method"+"\n"+
                 "*****************************************");
        System.out.println(store1.toString()+"\n");
        System.out.println("*****************************************"+
                 "\n"+"Testing the user defined methods"+"\n"+
                 "*****************************************");

        System.out.println("First word of store name: "+store1.getFirstWordOfStoreName());
        System.out.println("Middle word of the store name: "+store1.getMiddleWordOfStoreName());
        System.out.println("Last word of the store name: "+store1.getLatsWordOfStoreName()+"\n");
        store1.replaceStoreName("Timmy Tommy Enterprises","JC Penny Store");
        System.out.println("Printing the store1 object after invoking the replace method");
        System.out.println(store1.toString());
        System.out.println();
        Store store2=new Store();
        System.out.println("*********************************************************************"+
                 "\n"+"Testing the Getter methods or Accessors of Store Class with no-arg constructor"+"\n"+
                 "*********************************************************************");
        System.out.println("Store Name: "+store2.getStoreName());
        System.out.println("Store ID: "+store2.getStoreID());
        System.out.println("Street of the Store: "+store2.getStreet());
        System.out.println("City of the Store: "+store2.getCity());
        System.out.println("State of the Store: "+store2.getState());
        System.out.println("Zip code of the Store: "+store2.getZipCode());
        System.out.println("Phone number of the Store: "+store2.getPhoneNumber());
        System.out.println();
        store2.setStoreName("KC India Mart");
        store2.setStoreID(1001);
        store2.setPhoneNumber("9136818080");
        store2.setStreet("8542 w 133rd Street");
        store2.setCity("Overland Park");
        store2.setState("Kansas");
        store2.setCity("Overland Park");
        store2.setZipCode(66213);
        System.out.println("*********************************************************************"+
                 "\n"+"Testing the store class using toString after invoking the Setter methods or Mutators"+"\n"+
                 "*********************************************************************");
        System.out.println(store2.toString()+"\n");
        System.out.println("********************************************************"+
                 "\n"+"Testing the scanner class to take input from the console"+"\n"+
                 "********************************************************");
        Scanner scannerObject=new Scanner(System.in);
        System.out.println("Enter the store details");
        System.out.println("Enter the store name:");
        String storeName=scannerObject.nextLine();
        System.out.println("Enter the store ID:");
        int id=scannerObject.nextInt();
        scannerObject.nextLine();
        System.out.println("Enter the store phone number:");
        String phoneNumber=scannerObject.nextLine();
        System.out.println("Enter the street name of the store:");
        String street=scannerObject.nextLine();
        System.out.println("Enter the city name, state name, zip code of the store in one line without any commas:");
       String city=scannerObject.next();       
       String state=scannerObject.next();      
       int zipCode = scannerObject.nextInt();
        System.out.println();
       System.out.println("****************************************************"+
                 "\n"+"Testing the toString method without invoking the method"+"\n"+
                 "****************************************************");
        Store store3=new Store(storeName,id,phoneNumber,street,city,state,zipCode);
        System.out.println(store3);
        }

}
