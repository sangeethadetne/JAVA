/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GpaStudent;

/**
 * This class is used to define concrete class and scanner class
 * @author Sangeetha Detne
 * JDK 8.1 VERSION is used.
 */
public class GpaCal {
    private String firstName;
    private String lastName;
    private int sid;
    private char courseGrade1;
    private char courseGrade2;
    private char courseGrade3;
    
    /**
     *This is parameterized constructor ,where, it assigns the parameters to the local variables using "this" keyword
     * 
     * @param firstName //student firstname
     * @param lastName//student lastname
     * @param sid//student ID
     * @param courseGrade1//Course1 grade
     * @param courseGrade2//Course2 grade
     * @param courseGrade3//Course2 grade
     */
    public GpaCal(String firstName,String lastName,int sid,char courseGrade1
            ,char courseGrade2,char courseGrade3)
    {
        this.firstName=firstName;
        this.lastName=lastName;
        this.sid=sid;
        this.courseGrade1=courseGrade1;
        this.courseGrade2=courseGrade2;
        this.courseGrade3=courseGrade3;
    }

    /**
     *This method assigns values according to the student grades
     * @param grade //grade is parameter where it assigns a value
     * @return
     */
    public double grading(double grade)
    {
      double gradePoint=0.00;//if students has got c1=A C2=A c3=0 then gradefor
      //the third course is assigned as zero and calculates GPA
      if(grade=='A')
      {
        gradePoint=4.00;  
      }
      else if(grade=='B')
      {
          gradePoint=3.00;
      }
      else if(grade=='C')
      {
          gradePoint=2.00;
      }
      else if(grade=='D')
      {
          gradePoint=1.00;
      }
      else if(grade=='F')
      {
          gradePoint=0.00;
      }
      return gradePoint;
    } 
    
    /**
     *This method internally calls grading method and converts the grades into 
     * gradePoints and does the calculation and returns gpa
     * @param g1 // (double)course grade1
     * @param g2// (double)course grade2
     * @param g3// (double)course grade3
     * @return
     */
    public double CalculateGrading(double g1,double g2,double g3 )
     {
         double gradePoint1=grading(courseGrade1);
         double gradePoint2=grading(courseGrade2);
         double gradePoint3=grading(courseGrade3);
         
         double gpa=((gradePoint1 * 3)+(gradePoint2 * 3)+(gradePoint3 * 3))/9;
         return gpa;
         
      }
    /**
     * This toString() method is overridden and returns the 
     * first name
     * last name,grades of the three courses
     * @return 
     */
    @Override
     public String toString()
     {
        
         return "Student Name: "+ firstName+" ,"+lastName+"\n"+
                 "StudentId: "+sid+"\n"+
                 "Letter grade for the course: "+courseGrade1+"\n"+
                 "Letter grade for the course: "+courseGrade2+"\n"+
                 "Letter grade for the course: "+courseGrade3+"\n";
         
      }
    
    
    
}
    