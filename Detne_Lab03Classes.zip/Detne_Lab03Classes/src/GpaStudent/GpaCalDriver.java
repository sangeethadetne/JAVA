/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GpaStudent;

import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class GpaCalDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scr=new Scanner(System.in);
        System.out.println("Enter firstname: ");
        String FirstName=scr.next();
        System.out.println("Enter Lastname: ");
        String LastName=scr.next();
        System.out.println("Enter StudentID: ");
        int sid=scr.nextInt();
        scr.nextLine();
        System.out.println("Enter course1Grade: ");
        String c1=scr.next();
        System.out.println("Enter course2Grade: ");
        String c2=scr.next();
        System.out.println("Enter course3Grade: ");
        String c3=scr.next();
        GpaCal g1=new GpaCal(FirstName,LastName,sid,c1.charAt(0),c2.charAt(0),c3.charAt(0));
         double res =g1.CalculateGrading(c1.charAt(0),c2.charAt(0),c3.charAt(0));
        System.out.println("Final result is: "+res);
       
     }
    
}
