    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package jobapplication;

    import java.util.Date;
    import java.util.Scanner;

    /**
     *
     * @author Sangeetha Detne
     */
    public class Application
            implements Available {

        Applicant applicant;
        Job job;
        Supervisor supervisor;
        Scanner scr = new Scanner(System.in);

        public Application() {
            applicant = new Applicant();
        }

        private void assignLevelOfCommunicationSkills(String level) {

            applicant.setLevelOfCommunication(CommunicationSkill.valueOf(level.toUpperCase()).getLevelOfCommincationSkills());

        }

        @Override
        public boolean checkAge() {

            return applicant.getAge() > 20;
        }

        @Override
        public String checkAvailabilityOfJob() {
            Date d = new Date();

            if (d.before(job.closingDate)) {
                return "The job is still open, you can apply for this job";

            } else {
                return "The job dead line is closed you cannot apply for it";
            }

        }

        @Override
        public boolean checkQualification() {
            return applicant.getEducationQualification().equalsIgnoreCase("bachelors") ||
                    applicant.getEducationQualification().equalsIgnoreCase("masters");
        }

        public void fillJobApplicationDetails() {

            System.out.println("Enter your first name: ");
            String firstname = (scr.nextLine());
            applicant.setFirstName(firstname);
            System.out.println("Enter your last name: ");
            String lastname = (scr.nextLine());
            applicant.setLastName(lastname);
            System.out.println("Enter your phone number: ");
            String phno = (scr.nextLine());
            applicant.setPhoneNumber(phno);
            System.out.println("Enter your email id: ");
            String emailid = (scr.nextLine());
            applicant.setEmailID(emailid);
            System.out.println("Do you have any work experience: ");
            String workexp = (scr.nextLine());
            if (workexp.equalsIgnoreCase("yes")) {
                applicant.setWorkExperience(true);
            } else {
                applicant.setWorkExperience(false);
            }
            System.out.println("Enter your educational qualification: ");
            String eduqu = (scr.nextLine());
            applicant.setEducationQualification(eduqu);
            System.out.println("Enter your level of communication skills: ");
            String commskill = (scr.nextLine());
            assignLevelOfCommunicationSkills(commskill);

            System.out.println("Enter your age: ");
            int age = scr.nextInt();
            scr.nextLine();
            applicant.setAge(age);

        }

        @Override
        public boolean haveAGoodBackGround() {

            return (verifyBackGround().equals("You are eligible to apply"));
        }

        public void produceTheJobDescriptionForApplicant() {

            if (applicant.getEducationQualification().equalsIgnoreCase("masters") && applicant.getLevelOfCommunication() <= 2 && applicant.getAge() >= 25 && applicant.isWorkExperience()) {
                System.out.println("\nYou are eligible to apply for this job");
                supervisor = new Supervisor("John", "Ryan", "4125200909", "ryant@gmail.com");
                job = new Job(1100, "Senior Software Engineer", "Masters", new Date(2017, 9, 16), new Date(2017, 9, 20), 50000, "You have develop software solutions and supervise the team under you", supervisor);

                System.out.println(job.printJobDetails());

            } else if (applicant.getEducationQualification().equalsIgnoreCase("masters") && applicant.getLevelOfCommunication() <= 3 && applicant.getAge() >= 23 && !applicant.isWorkExperience()) {
                System.out.println("\nYou are eligible to apply for this job");
                supervisor = new Supervisor("Feon", "Tim", "5125280229", "timf@gmail.com");
                job = new Job(1103, "Software Engineer", "Bachelors", new Date(2107, 8, 27), new Date(2017, 9, 14), 50000, "You have to develop software solutions", supervisor);
                System.out.println(job.printJobDetails());

            } else if (checkQualification() && applicant.getLevelOfCommunication() <= 3 && applicant.getAge() >= 22 && applicant.isWorkExperience()) {
                System.out.println("\nYou are eligible to apply for this job");
                supervisor = new Supervisor("William", "Lee", "3206300980", "leew@gmail.com");
                job = new Job(1200, "Back end Developing", "Bachelors", new Date(2107, 9, 10), new Date(2017, 9, 13), 50000, "Have to write the code for server operations and data bases", supervisor);
                System.out.println(job.printJobDetails());

            } else if (applicant.getEducationQualification().equalsIgnoreCase("bachelors") && applicant.getLevelOfCommunication() <= 3 && applicant.getAge() >= 22 && !applicant.isWorkExperience()) {
                System.out.println("\nYou are eligible to apply for this job");
                supervisor = new Supervisor("David", "Martin", "4126290129", "martindav@gmail.com");
                job = new Job(1300, "Front End Designer", "Bachelors", new Date(2107, 9, 13), new Date(2017, 9, 20), 50000, "Have to write the code for front end and work with design aspects", supervisor);
                System.out.println(job.printJobDetails());

            } else if (applicant.getEducationQualification().equalsIgnoreCase("bachelors") && applicant.getLevelOfCommunication() == 5 && applicant.getAge() > 20) {
                System.out.println("\nYou are eligible to apply for this job");
                supervisor = new Supervisor("Jose", "Ellizibeth", "3124482379", "s527890@gmail.com");
                job = new Job(1350, "Technical Support Associate", "Bachelors", new Date(2107, 9, 16), new Date(2017, 9, 20), 50000, "Have to collect the required documents and answer the call of customers", supervisor);
                System.out.println(job.printJobDetails());
            } else {
                System.out.println("\nNot Eligible to apply for the jobs that are currently available");
            }

        }

        @Override
        public String verifyBackGround() {
            String f1, c1, t1;
            System.out.println("Have you ever been convicted for felony:");
            f1 = scr.nextLine();
            System.out.println("Are you a social worker part of criminal justice system:");
            c1 = scr.nextLine();
            System.out.println("Have you ever charged for traffic violations:");
            t1 = scr.nextLine();
            if (f1.equalsIgnoreCase("yes") || c1.equalsIgnoreCase("yes") || t1.equalsIgnoreCase("yes")) {
                return "You are not eligible to apply";
            } else {
                return "You are eligible to apply";
            }

        }

        @Override
        public String toString() {

            return "\nApplicant Details\n" + applicant + "\nThe details of job the applicant applied for \n" + job + "\n" + "Details of supervisor for this job: \n" + supervisor;
        }

    }
