    /*Devin
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package jobapplication;

    import java.util.ArrayList;
    import java.util.Scanner;

    /**
     *
     * @author Sangeetha Detne
     */
    public class ApplicationDriver {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
            // TODO code application logic here
            String t = "yes";
            ArrayList<Application> applicationsList = new ArrayList<>();
            System.out.println("************************************\n"
                    + "Welcome to the Career Builder System\n"
                    + "************************************");
            Scanner scr = new Scanner(System.in);
            while (t.equalsIgnoreCase("yes")) {
                System.out.println("Fill your details to know the jobs that suits your profile");
                System.out.println("");
                Application application = new Application();
                application.fillJobApplicationDetails();
                if (application.haveAGoodBackGround()) {
                    if (application.checkQualification()) {
                        if (application.checkAge()) {

                            application.produceTheJobDescriptionForApplicant();
                            if (application.checkAvailabilityOfJob().contains("open")) {
                                System.out.println(application.checkAvailabilityOfJob());
                                System.out.println("Would you like to apply for this job");
                                if (scr.nextLine().equalsIgnoreCase("yes")) {
                                    applicationsList.add(application);

                                }
                            } else {
                                System.out.println(application.checkAvailabilityOfJob());
                            }
                            System.out.println("Would you like to apply for another applicant");
                            t = scr.nextLine();

                        }
                    } else {
                        System.out.println("You need a higher need to apply the job posistions we have currently");
                        System.exit(0);
                    }

                } else {
                    System.out.println("You shouldn't have any criminal or illicit background");
                    System.exit(0);
                }

            }
            
            if (applicationsList.size() > 0) {
                System.out.println("*********************************************\n"
                        + "Here is the list of applications you created ");
                System.out.println("");
                for (int i = 0; i < applicationsList.size(); i++) {
                    System.out.println(applicationsList.get(i));
                    System.out.println("*********************************************");
                }
            }
        }

    }
