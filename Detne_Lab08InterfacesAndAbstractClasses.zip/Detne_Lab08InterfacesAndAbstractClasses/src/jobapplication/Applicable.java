/*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
 */
package jobapplication;

/**
 *
 * @author Sangeetha Detne
 */
public interface Applicable {

    public abstract boolean haveAGoodBackGround();

    public abstract String verifyBackGround();

}
