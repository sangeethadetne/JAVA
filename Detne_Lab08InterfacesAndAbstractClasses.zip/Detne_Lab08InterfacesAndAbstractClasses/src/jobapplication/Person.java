    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package jobapplication;

    /**
     *
     * @author Sangeetha Detne
     */
    public abstract class Person {

        String firstName;
        String lastName;
        String phoneNumber;
        String emailID;

        public Person() {
        }

        public Person(String firstName, String lastName, String phoneNumber, String emailID) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.emailID = emailID;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public String getFormattedPhoneNumber(String phoneNumber) {
            String s = phoneNumber.trim();
            return "+1(" + s.substring(0, 3) + ")" + s.substring(3, 6) + "-" + s.substring(6);
        }

        public abstract String getFullName();

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getEmailID() {
            return emailID;
        }

        public void setEmailID(String emailID) {
            this.emailID = emailID;
        }

        @Override
        public String toString() {
            return "Contact Details: " + getEmailID() + ", " + getFormattedPhoneNumber(phoneNumber);
        }

    }
