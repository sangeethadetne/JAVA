    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package jobapplication;

    /**
     *
     * @author Sangeetha Detne
     */
    public class Supervisor extends Person {

        public Supervisor() {
            super();
        }

        public Supervisor(String firstName, String lastName, String phoneNumber, String emailID) {
            super(firstName, lastName, phoneNumber, emailID);
        }

        @Override
        public String getFullName() {
            return super.getFirstName() + " " + super.getLastName() + " ( " + super.getFirstName().substring(0, 1) + "." + super.getLastName().substring(0, 1) + " )";
        }

        @Override
        public String toString() {
            return "Name of the supervisor: " + getFullName() + "\n" + super.toString();
        }

    }
