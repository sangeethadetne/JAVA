    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package jobapplication;

    /**
     *
     * @author Sangeetha Detne
     */
    public enum CommunicationSkill {
        AVERAGE(4), EXCELLENT(1), FAMILIAR(5), KNOWLEDGEABLE(3), PROFICIENT(2);

        private CommunicationSkill(int levelOfCommincationSkills) {
            this.levelOfCommincationSkills = levelOfCommincationSkills;
        }

        private int levelOfCommincationSkills;

        public int getLevelOfCommincationSkills() {
            return levelOfCommincationSkills;
        }

    }
