/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.ArrayList;
import ship.Point;
import ship.Ship;

/**
 *This is a utility class 
 * @author Sangeetha Detne
 */
public class Utility {

    private Utility() {
    }

    /**
     *This is a getdistance() method which takes two points which used for calculation of the distance
     * @param p1 stores the point 1 values
     * @param p2 stores the point2 values
     * @return  distance between two points
     */
    public static double getDistance(Point p1, Point p2) {

        return Math.sqrt(Math.pow((p2.getY() - p1.getY()), 2) + Math.pow((p2.getX() - p1.getX()), 2));
    }

    /**
     *This is a method which calculates the distance of one ship with the another 
     * @param shp stores the ship
     * @param ships stores the arraylist of the ship
     * @return distanceString 
     */
    public static String knowHowFarIsYourShipFromOthers(Ship shp, ArrayList<Ship> ships) {

        String distanceString = "Distance between " + shp.getShipName() + " and";

        for (Ship s : ships) {
            if (!s.getShipName().equals(shp.getShipName())) {
                distanceString += "\n 		  " + s.getShipName() + ":" + String.format("%.2f", Math.round(getDistance(shp.getSourceLoctaion(), s.getSourceLoctaion()) * 100) / 100.0);
            }
        }
        return distanceString;

    }
}
