/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 * This is a enum calss with all enums declared
 *
 * @author Sangeetha Detne
 */
public enum Facilities {

    /**
     * This enum variable contains facility value for Casino
     */
    CASINO(100),
    /**
     * This enum variable contains facility value for Spa
     */
    SPA(65),
    /**
     * This enum variable contains facility value for Gym
     */
    GYM(50),
    /**
     * This enum variable contains facility value for games
     */
    GAMES(80),
    /**
     * This enum variable contains facility value for BuffetRestaurant
     */
    BUFFETRESTAURANT(120),
    /**
     * This enum variable contains facility value for Food
     */
    FOOD(20),
    /**
     * This enum variable contains facility value for UpperDeck
     */
    UPPERDECK(20),
    /**
     * This enum variable contains facility value for Drinks
     */
    DRINKS(10);

    private double facilityPrice;

    private Facilities(double facilityPrice) {
        this.facilityPrice = facilityPrice;
    }

    /**
     * This is a getter method for the facility price
     *
     * @return facility price
     */
    public double getFacilityPrice() {
        return facilityPrice;
    }

    /**
     * This method sets the facility price
     *
     * @param facilityPrice stores the facility price variable.
     */
    public void setFacilityPrice(double facilityPrice) {
        this.facilityPrice = facilityPrice;
    }

}
