/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 * This is goodbase enum with all constant
 *
 * @author Sangeetha Detne
 */
public enum GoodsBaseCost {

    /**
     * This enum variable contains the intialcost for low and heavy weight of
     * the animal.
     */
    ANIMALS(1000, 2000),
    /**
     * This chemical enum variable contains the initial low and heavy weight.
     */
    CHEMICAL(1000, 3000),
    /**
     * This wood enum variable contains the initial cost for low and heavy
     * weight.
     */
    WOOD(900, 2000),
    /**
     * This vehicle enum variable contains the initial cost for LowWeight and
     * HeavyWeight.
     */
    VEHICLES(1100, 2500),
    /**
     * This others enum variable contains Initial cost for LowWeight and
     * HeavyWeight.
     */
    OTHERS(800, 1600);

    private double initialCostForLowWeight;
    private double initialCostForHeavyWeight;

    /*
    This is a parameterized constructor
     */
    private GoodsBaseCost(double initialCostForLowWeight, double initialCostForHeavyWeight) {
        this.initialCostForLowWeight = initialCostForLowWeight;
        this.initialCostForHeavyWeight = initialCostForHeavyWeight;
    }

    /**
     * This method is a static method for the animals
     *
     * @return value of the animals
     */
    public static GoodsBaseCost getANIMALS() {
        return ANIMALS;
    }

    /**
     * This methods returns the value of Chemicals.
     *
     * @return chemical value
     */
    public static GoodsBaseCost getCHEMICAL() {
        return CHEMICAL;
    }

    /**
     * This method returns the value of the wood
     *
     * @return value of the wood
     */
    public static GoodsBaseCost getWOOD() {
        return WOOD;
    }

    /**
     * This methods returns the value of Vehicles.
     *
     * @return vehicle value
     */
    public static GoodsBaseCost getVEHICLES() {
        return VEHICLES;
    }

    /**
     * This methods returns the value of Others.
     *
     * @return value of the others
     */
    public static GoodsBaseCost getOTHERS() {
        return OTHERS;
    }

    /**
     * This is the getter method for the intialCostForLowWeight()
     *
     * @return InitialCostForLowWeight
     */
    public double getInitialCostForLowWeight() {
        return initialCostForLowWeight;
    }

    /**
     * This is the getter method for the getInitialCostForHeavyWeight()
     *
     * @return getInitialCostForHeavyWeight
     */
    public double getInitialCostForHeavyWeight() {
        return initialCostForHeavyWeight;
    }

}
