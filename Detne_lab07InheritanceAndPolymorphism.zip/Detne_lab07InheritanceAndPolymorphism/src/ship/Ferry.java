/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

import enums.Facilities;
import util.Utility;

/**
 * This class ferry extends the PassengerShip
 *
 * @author Sangeetha Detne
 */
public class Ferry extends PassengerShip {

    private double time;

    /**
     * This is a non-parameterized Constructor that calls super class
     * constructor
     */
    public Ferry() {
        super();
    }

    /**
     * This method assigns time using this keyword
     *
     * @param time is the time taken for the travel
     */
    public Ferry(double time) {
        this.time = time;
    }

    /**
     * This is a parameterized constructor with two paramaters.
     *
     * @param time stores the time taken for the travel
     * @param basePrice stores the base price for the facilities.
     */
    public Ferry(double time, double basePrice) {
        super(basePrice);
        this.time = time;
    }

    /**
     * This is a parameterized constructor with all parameters
     *
     * @param manufactureName It stores the name of the Manufacturer.
     * @param modelSeries It stores the model Series of the ship
     * @param shipName It stores the ship Name.
     * @param sourceLoctaion It stores the starting location before travel
     * @param destinationLocation It stores the Destination location
     * @param model stores the model of the ship.
     * @param basePrice stores the base price for the facilities.
     * @param time stores the time taken for the travel
     */
    public Ferry(String manufactureName, int modelSeries, String shipName,
            Point sourceLoctaion, Point destinationLocation,
            String model, double basePrice, double time) {
        super(manufactureName, modelSeries, sourceLoctaion, destinationLocation,
                shipName, model, basePrice);
        this.time = time;
    }

    /**
     * This is a getter method for the time
     *
     * @return the time taken by the ship using this keyword
     */
    public double getTime() {
        return time;
    }

    /**
     * This is a setter method for the time
     *
     * @param time sets the time for ship using this keyword
     */
    public void setTime(double time) {
        this.time = time;
    }

    /**
     * This is a getter method the speed using getdistance() method
     *
     * @return the speed of ship for the distance traveled.
     */
    public double getSpeed() {

        return Utility.getDistance(getSourceLoctaion(), getDestinationLocation()) / this.time;
    }

    /**
     * This calculate cost method which overrides the superclass calculate
     * method
     *
     * @return the cost for the facilities with the base price
     */
    public double calculateCost() {
        double i = 0;
        for (String s : getFacilities()) {
            i += Facilities.valueOf(s.toUpperCase()).getFacilityPrice();
        }

        return i + getBasePrice();
    }

    @Override
    public String toString() {

        return "Ferry Name: " + getShipName() + ", " + getModel() + getModelSeries()
                + "\nThe Base price of ticket is: $" + getBasePrice()
                + "\nThe facilities chosen are " + getFacilities() + " and the total cost is: $" + calculateCost()
                + "\nThe Speed at which the ferry is travelling: " + Math.round(getSpeed() * 100) / 100.0 + "mph";
    }

}
