/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

/**
 *This ship class
 * @author Sangeetha Detne
 */
public class Ship {

    private String manufactureName;
    private int modelSeries;
    private Point sourceLoctaion;
    private Point destinationLocation;
    private String shipName;
    private String model;

    /**
     * This is non parameterized constructor
     */
    public Ship() {
    }

    /**
     * This is parameterized constructor with all the parameters 
     * @param manufactureName It stores the name of the Manufacturer.
     * @param modelSeries It stores  the model Series of the ship
     * @param shipName It stores the ship Name.
     * @param sourceLoctaion It stores  the starting location before travel
     * @param destinationLocation It stores the Destination location
     * @param model It stores the model of the ship.
     */
    public Ship(String manufactureName, int modelSeries, Point sourceLoctaion, Point destinationLocation, String shipName, String model) {
        this.manufactureName = manufactureName;
        this.modelSeries = modelSeries;
        this.sourceLoctaion = sourceLoctaion;
        this.destinationLocation = destinationLocation;
        this.shipName = shipName;
        this.model = model;
    }

    /**
     * This is getter method the manufacturer Name
     * @return the Manufacturer name
     */
    public String getManufactureName() {
        return manufactureName;
    }

    /**
     *This is setter method the manufacturer Name
     * @param manufactureName stores the name of the manufacture 
     */
    public void setManufactureName(String manufactureName) {
        this.manufactureName = manufactureName;
    }

    /**
     *This is getter method the modelseries
     * @return the Model Series
     */
    public int getModelSeries() {
        return modelSeries;
    }

    /**
     *This is setter method the modelseries
     * @param modelSeries stores the model series no
     */
    public void setModelSeries(int modelSeries) {
        this.modelSeries = modelSeries;
    }

    /**
     *This is getter method the sourceLocation
     * @return the source Location
     */
    public Point getSourceLoctaion() {
        return sourceLoctaion;
    }

    /**
     *This is getter method the sourceLocation
     * @param sourceLoctaion stores the ship source location
     */
    public void setSourceLoctaion(Point sourceLoctaion) {
        this.sourceLoctaion = sourceLoctaion;
    }

    /**
     *This is getter method for the destination location
     * @return the destination location
     */
    public Point getDestinationLocation() {
        return destinationLocation;
    }

    /**
     * This is setter method for the destination location
     * @param destinationLocation sets the ship destination location
     */
    public void setDestinationLocation(Point destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    /**
     *This is getter method for the ship name
     * @return the ship Name
     */
    public String getShipName() {
        return shipName;
    }

    /**
     *This is setter method for the ship name
     * @param shipName stores the ship name
     */
    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    /**
     *This is getter method for the ship model
     * @return the model of ship
     */
    public String getModel() {
        return model;
    }

    /**
     *This is setter method for the ship model
     * @param model stores the ship model
     */
    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return manufactureName;
    }

}
