/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

import enums.Facilities;

/**
 *This class cruise extends PassengerShip
 * @author Sangeetha Detne
 */
public class Cruise extends PassengerShip {

    /**
     * This is a non-parameterized Constructor that calls super class
     * constructor
     */
    public Cruise() {
        super();
    }

    /**
     *
     * @param manufactureName It stores  the name of the Manufacturer.
     * @param modelSeries It stores the model Series of the ship
     * @param shipName It stores the ship Name.
     * @param sourceLoctaion It stores the starting location before travel
     * @param destinationLocation It stores the Destination location
     * @param model It stores the model of the ship.
     * @param basePrice It stores the base price for the facilities.
     */
    public Cruise(String manufactureName, int modelSeries, String shipName, Point sourceLoctaion, Point destinationLocation, String model, double basePrice) {
        super(manufactureName, modelSeries, sourceLoctaion, destinationLocation, shipName, model, basePrice);
    }

    /**
     *
     * This method calculates the price of the facilities
     * @return the cost for the facilities with the base price.
     */
    @Override
    public double calculateCost() {
        double i = 0;
        for (String s : getFacilities()) {
            i += Facilities.valueOf(s.toUpperCase()).getFacilityPrice();
        }

        return i + getBasePrice();
    }

   
    @Override
    public String toString() {
        return "Cruise Name: " + getShipName() + ", " + getModel() + getModelSeries()
                + "\nThe Base price of the ticket is: $" + getBasePrice()
                + "\nThe facilities chosen are: " + getFacilities()
                + " and the total cost calculated is: $" + calculateCost();
    }

}
