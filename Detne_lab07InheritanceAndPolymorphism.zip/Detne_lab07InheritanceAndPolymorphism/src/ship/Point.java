/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

/**
 * This is a point class 
 * @author Sangeetha Detne
 */
public class Point {

    private double X;
    private double Y;

    /**
     *This is a constructors with two parameters
     * @param X stores  the X-coordinate of the ship location
     * @param Y stores the Y-coordinate of the ship location
     */
    public Point(double X, double Y) {
        this.X = X;
        this.Y = Y;
    }

    /**
     * This  is a getter method for the x-coordinate
     * @return X
     */
    public double getX() {
        return X;
    }

    /**
     *This  is a setter method for the x-coordinate
     * @param X is the X-coordinate for the location
     */
    public void setX(double X) {
        this.X = X;
    }

    /**
     *This  is a getter method for the y-coordinate
     * @return Y
     */
    public double getY() {
        return Y;
    }

    /**
     *This  is a setter method for the x-coordinate
     * @param Y is the Y-coordinate for the location
     */
    public void setY(double Y) {
        this.Y = Y;
    }

}
