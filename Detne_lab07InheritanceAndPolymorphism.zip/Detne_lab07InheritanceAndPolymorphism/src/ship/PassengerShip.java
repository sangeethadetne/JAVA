/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

import java.util.ArrayList;

/**
 *This is a passengerShip class which inherits ship class
 * @author Sangeetha Detne
 */
public class PassengerShip extends Ship {

    private double basePrice;
    private ArrayList<String> facilities;

    /**
     * This is a parameterised  Constructor that calls super class constructor
     */
    public PassengerShip() {
        super();
    }

    /**
     * This is a passenger ship class with one constructor
     * @param basePrice the base price for the facilities.
     */
    public PassengerShip(double basePrice) {
        this.basePrice = basePrice;
    }

    /**
     * This is parametrized constructors with all the parameters
     * @param manufactureName It stores the name of the Manufacturer.
     * @param modelSeries It stores model Series of the ship
     * @param shipName It stores the ship Name.
     * @param sourceLoctaion It stores the starting location before travel
     * @param destinationLocation It stores the Destination location
     * @param model It stores the model of the ship.
     * @param basePrice It stores the base price for the facilities.
     *
     */
    public PassengerShip(String manufactureName, int modelSeries, Point sourceLoctaion, Point destinationLocation, String shipName, String model, double basePrice) {
        super(manufactureName, modelSeries, sourceLoctaion, destinationLocation, shipName, model);
        this.basePrice = basePrice;
        facilities = new ArrayList<>();
    }

    /**
     * This  is a getter method for the base price
     * @return the base price of facilities.
     */
    public double getBasePrice() {
        return basePrice;
    }

    /**
     * This is a setter method for the base price
     * @param basePrice is the base price for the facilities.
     */
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    /**
     * This method stores facilities in the array
     * @return the facilities ArrayList
     */
    public ArrayList<String> getFacilities() {
        return facilities;
    }

    /**
     *This is setter method for the facilities
     * @param facilities stores the elements in the facilities Array
     */
    public void setFacilities(ArrayList<String> facilities) {
        this.facilities = facilities;
    }

    /**
     * This method used to add facilities in tha arraylist
     * @param options stores the String that contains facilities.
     * @return the facilities ArrayList.
     */
    public ArrayList<String> addFacilities(String options) {
        for (String s : options.split(",")) {
            facilities.add(s);
        }
        return facilities;
    }

    /**
     *This method calculates cost of the facilities and overrides the super class calculate cost  
     * @return the base cost
     */
    public double calculateCost() {
        return this.basePrice;
    }

    @Override
    public String toString() {
        return facilities + "";
    }

}
