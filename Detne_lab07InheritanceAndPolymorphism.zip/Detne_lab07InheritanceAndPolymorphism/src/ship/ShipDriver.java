/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @author Sangeetha Detne
 */
public class ShipDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        Scanner scr = new Scanner(new File("ship.txt"));
        String manufactureName = scr.nextLine().trim();
        int modelSeriesTag = scr.nextInt();
        ArrayList<Ship> shiplist = new ArrayList<>();
        System.out.println("*****************************************************************");
        System.out.println("Welcome to " + manufactureName);
        System.out.println("*****************************************************************\n");
        while (scr.hasNext()) {
            String shipType = scr.nextLine().trim();

            if (shipType.equals("Passenger Ship")) {

                String model1 = scr.nextLine().trim();
                String ShipName = scr.nextLine().trim();
                Point p1 = new Point(Double.parseDouble(scr.next()), Double.parseDouble(scr.next()));
                Point p2 = new Point(Double.parseDouble(scr.next()), Double.parseDouble(scr.nextLine().trim()));

                String modelSeries = scr.nextLine();
                Double BasePrice = scr.nextDouble();
                scr.nextLine();

                    /*
                    * below the passenger class object is created and feerry is asigned and insantiated in this way
                    */
                if (model1.equals("Cruise")) {
                    PassengerShip cru = new Cruise(manufactureName, modelSeriesTag, ShipName, p1, p2, modelSeries, BasePrice);
                    
                    shiplist.add(cru);

                    cru.addFacilities(scr.nextLine().trim());
                    System.out.println("Cruise details: ");
                    System.out.println(cru.toString());
                    if (shiplist.size() > 1) {
                        System.out.println(util.Utility.knowHowFarIsYourShipFromOthers(cru, shiplist));
                    }
                    System.out.println("*****************************************************************\n");
                } else if (model1.equals("Ferry")) {
                    double time = scr.nextDouble();
                    scr.nextLine();
                    PassengerShip fry = new Ferry(manufactureName, modelSeriesTag, ShipName, p1, p2, modelSeries, BasePrice, time);
                    shiplist.add(fry);
                   
                    fry.addFacilities(scr.nextLine().trim());
                    System.out.println("Ferry details: ");
                    System.out.println(fry.toString());
                    if (shiplist.size() > 1) {
                        System.out.println(util.Utility.knowHowFarIsYourShipFromOthers(fry, shiplist));
                    }
                    System.out.println("*****************************************************************\n");
                }
            } else if (shipType.equals("Cargo Ship")) {
                String type = scr.nextLine().trim();
                Good g = new Good(type, Integer.parseInt(scr.nextLine()), Double.parseDouble(scr.nextLine()));
                String shipName = scr.nextLine().trim();
                Point p1 = new Point(Double.parseDouble(scr.next()), Double.parseDouble(scr.next()));
                Point p2 = new Point(Double.parseDouble(scr.next()), Double.parseDouble(scr.nextLine().trim()));
                String modelSeries = scr.nextLine();

                CargoShip crg = new CargoShip(manufactureName, modelSeriesTag, shipName, p1, p2, "Cargo");
                crg.addGoods(g);
                shiplist.add(crg);
                System.out.println("Cargo Ship details: ");
                System.out.println(crg.toString());
                if (shiplist.size() > 1) {
                    System.out.println(util.Utility.knowHowFarIsYourShipFromOthers(crg, shiplist));
                }
                System.out.println("*****************************************************************\n");
            }
        }

    }

}
