/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

/**
 * This is a good class
 *
 * @author Sangeetha Detne
 */
public class Good {

    private String type;
    private int stockID;
    private double stockWeight;

    /**
     * This is a parameterized constructor with three parameters
     *
     * @param type stores the type of Good
     * @param stockID stores the Id of Good
     * @param stockWeight stores the weight for the Good
     */
    public Good(String type, int stockID, double stockWeight) {
        this.type = type;
        this.stockID = stockID;
        this.stockWeight = stockWeight;
    }

    /**
     * This method get the good type
     *
     * @return the type of Goods
     */
    public String getType() {
        return type;
    }

    /**
     * This method sets the good type
     *
     * @param type stores the type of Goods
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * This method get the stock id of the good
     *
     * @return the Id for the Goods
     */
    public int getStockID() {
        return stockID;
    }

    /**
     * This method sets the stockId of the good
     *
     * @param stockID stores the Id of Goods
     */
    public void setStockID(int stockID) {
        this.stockID = stockID;
    }

    /**
     * This method gets the stockweight
     *
     * @return the stock weight for the Goods
     */
    public double getStockWeight() {
        return stockWeight;
    }

    /**
     *
     * @param stockWeight is the weight for the Good
     */
    public void setStockWeight(double stockWeight) {
        this.stockWeight = stockWeight;
    }

}
