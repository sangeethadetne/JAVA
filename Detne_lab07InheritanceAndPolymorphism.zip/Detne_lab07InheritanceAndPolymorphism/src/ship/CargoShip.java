/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ship;

import java.util.ArrayList;
import enums.GoodsBaseCost;
import util.Utility;

/**
 * This is subclass which inherits passengerShip
 *
 * @author Sangeetha Detne
 */
public class CargoShip extends Ship {

    private ArrayList<Good> goods;

    /**
     * This is non parameterized argument constructor which calls the super
     * class constructor
     */
    public CargoShip() {
        super();
    }

    /**
     * This method creates the array list of the Good
     *
     * @param goods is of type ArrayList contains goods.
     */
    public CargoShip(ArrayList<Good> goods) {
        this.goods = goods;
    }

    /**
     * This is the parameterized constructor which calls super class
     * constructors
     *
     * @param manufactureName It stores the name of the manufacturer.
     * @param modelSeries It stores the ship model Series
     * @param shipName It stores the ship Name.
     * @param sourceLoctaion It stores the starting location of the ship.
     * @param destinationLocation It stores the Destination location of the ship.
     * @param model It stores the model of the ship.
     */
    public CargoShip(String manufactureName, int modelSeries, String shipName, Point sourceLoctaion, Point destinationLocation, String model) {
        super(manufactureName, modelSeries, sourceLoctaion, destinationLocation, shipName, model);
        goods = new ArrayList<>();
    }

    /**
     * This method adds the options to the arraylist
     *
     * @param options takes the options.
     * @return the goods arrayList.
     */
    public ArrayList<Good> addGoods(Good options) {
        goods.add(options);
        return goods;
    }

    /**
     * This is method calls the distance method in the getDistance(Point p1,
     * Point p2) in the utility class
     *
     * @return the Distance traveled by the ship
     */
    public double getDistance() {
        return Utility.getDistance(getSourceLoctaion(), getDestinationLocation());

    }

    /**
     * This method calculates the weight and distance based the goods arrived
     *@return the cost based on the product
     */
    public double calcCostBasedOnWeightNDist() {

        for (Good g : goods) {
            if (g.getStockWeight() >= 2000 && getDistance() >= 1000) {
                return GoodsBaseCost.valueOf(g.getType().toUpperCase()).getInitialCostForHeavyWeight() + 2.60 * getDistance();
            } else if (g.getStockWeight() < 2000 && getDistance() >= 1000) {
                return GoodsBaseCost.valueOf(g.getType().toUpperCase()).getInitialCostForLowWeight() + 2.60 * getDistance();
            } else if (g.getStockWeight() < 2000 && getDistance() < 1000) {
                return GoodsBaseCost.valueOf(g.getType().toUpperCase()).getInitialCostForLowWeight() + 1.33 * getDistance();
            } else if (g.getStockWeight() >= 2000 && getDistance() < 1000) {
                return GoodsBaseCost.valueOf(g.getType().toUpperCase()).getInitialCostForHeavyWeight() + 1.33 * getDistance();
            }
        }

        return 0.0;
    }

    /**
     * This method calculates the cost of the good along with the tax
     *
     * @return the cost based on weight and distance including tax for the
     * particular good.
     */
    public double calculateCostWithTax() {
        double total = 0;
        for (Good g : goods) {
            if (g.getType().equals("Chemical")) {

                return calcCostBasedOnWeightNDist() * 1.14;
            } else if (g.getType().equals("Wood")) {
                return calcCostBasedOnWeightNDist() * 1.10;
            } else if (g.getType().equals("Food")) {
                return calcCostBasedOnWeightNDist() * 1.12;
            } else {
                return calcCostBasedOnWeightNDist() * 1.08;
            }
        }

        return 0.0;
    }

    @Override
    public String toString() {
        return "Cargo Ship Name: " + getShipName() + "\nThe distance to be travelled by the ship is "
                + Math.round(getDistance() * 100) / 100.0 + " miles\nThe type of stock on the ship is " + "'" + goods.get(0).getType() + "' "
                + "weighing " + goods.get(0).getStockWeight() + " tons\n"
                + "The total cost calculated to carry the stock is: $" + Math.round(calculateCostWithTax() * 100) / 100.0;
    }

}
