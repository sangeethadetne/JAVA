/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feecalculator;

/**
 *
 * @author Sangeetha Detne
 */
public class FeeCalculator {
    
    /**
     *constant incidental fee is stored here for undergraduate
     */
    public static final double UG_INCIDENTAL_FEE = 406.35;

    /**
     *constant designated fee is stored for UG
     */
    public static final double UG_DESIGNATED_FEE = 104.80;

    /**
     *constant textbook fee is stored for UG
     */
    public static final double UG_TEXTBOOK_FEE = 6.00;

    /**
     *constant technology fee is stored for UG
     */
    public static final double UG_TECHNOLOGY_FEE = 20.70;

    /**
     *constant computerScience fee is included for UG
     */
    public static final double UG_COMPUTERSCIENCE_FEE = 38.00;
    
    /**
     *PG incidential fee is stored for PG
     */
    public static final double PG_INCIDENTAL_FEE = 505.72;

    /**
     *PG designated fee is stored for PG
     */
    public static final double PG_DESIGNATED_FEE = 115.55;

    /**
     *PG textbook fee is stored in variable for for PG 
     */
    public static final double PG_TEXTBOOK_FEE = 0;

    /**
     *PG technology fee is included for PG
     */
    public static final double PG_TECHNOLOGY_FEE = 20.70;

    /**
     *PG computer science fee is stored for PG
     */
    public static final double PG_COMPUTERSCIENCE_FEE = 38.00;
    
    /**
     *PG international scholarship fee is stored in variable for PG
     */
    public static final double PG_IGA_SCHLOARSHIP = 1000;
    
    /**
     *PG semester 1 insurance for PG
     */
    public static final double PG_SEM1_INS =456.48;

    /**
     *PG semester 2 insurance for PG
     */
    public static final double PG_SEM2_INS =760.2 ;

    /**
     *PG semester3 insurance for PG
     */
    public static final double PG_SEM3_INS =330.1 ;

    /**
     *PG semester 4 insurance for PG
     */
    public static final double PG_SEM4_INS =456.48 ;
    
    /**
     * constant Indian rupee cost=64.55
     */
    public static final double PG_INDIA_RUPEE =64.55 ;

    /**
     *constant UK Euro cost=0.83
     */
    public static final double PG_UK_EURO =0.83 ;
    
    /**
     * constant International service fee for all students
     */
    public static final double PG_ISA_FEE = 75.00 ;

    /**
     *orientation fee is included for all students
     */
    public static final double PG_ORIENTATION_FEE = 75.00 ;
    
   
    
    private String studentName;
   
    
    /**
     * This is parameterized constructor method which return studentName
     * @param studentName  stores studentName
     */
    
    public FeeCalculator(String studentName)
    {
        this.studentName=studentName;
    }
     /**
     * This is getter method which return studentName
     * @return  studentName
     */
    private String getStudentName() {
        return studentName;
    }
    /**
     *This is setter method where it takes studentName as its input
     * @param studentName takes student Name
     */

    private void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    
    /**
     * This method takes input string and returns Initials with "." eg: sangeetha Detne-- S.D
     * @return string a which store initials with dot(.)
     */
    public String getNameInitials(){      
       
       String a = "";
       studentName = studentName.toUpperCase();
        String[] s = studentName.split(" ");
        for(int i=0;i<s.length;i++)
       {
           a = a + s[i].charAt(0)+".";
       }
       return a;
       }
    /**
     *This method  calculates the prerequisite cost which takes prerequisite no
     * @return  cost of prerequisite 
     */
   
   private double calcPrereqCost(int noOfPrequite){
    double calculatedPrequiteCost = 0.00;
       if (noOfPrequite<=2){
            calculatedPrequiteCost =(UG_INCIDENTAL_FEE + UG_DESIGNATED_FEE +
                    UG_TEXTBOOK_FEE + UG_TECHNOLOGY_FEE + UG_COMPUTERSCIENCE_FEE)*3*noOfPrequite;
       }
       
        
        return calculatedPrequiteCost ;
       }
   /**
     *This method calculates courses according to the prerequisite eg:for prerequisite=1 courses =3;
     * @return no of course
     */
   
   private int findReqCoursesForSem1(int noOfPrequite){
       int n = 0;
       if(noOfPrequite==0)
           n=3;
       else if(noOfPrequite==1 || noOfPrequite==2)
           n=2;
       else
           n=0;
       return n;
      }
   
    /**
     *This method calculates cost for the one course and later it is multiplied with 3
     * @return courseCost for one course
     */
    private double calcReqCourseCostForOneCourse()
   {
       double courseCost;
       courseCost = 0.0;
       courseCost=(PG_INCIDENTAL_FEE + PG_DESIGNATED_FEE +
                    PG_TEXTBOOK_FEE + PG_TECHNOLOGY_FEE + PG_COMPUTERSCIENCE_FEE)*3;
        return courseCost; 
   }

    /**
     *This method calculates scholarship for the each sem and in fourth sem students with prerequisite=0 
     * has courses either 3 or 2
     * @param semester
     * @param noOfPrequite
     * @param gpa
     * @return scholarship
     */
    private double calcScholarship(int semester, int noOfPrequite, double gpa){
       double Schloarship=0.0;
       if(semester==1){
           Schloarship=PG_IGA_SCHLOARSHIP;
       }
       else
       {
           if(gpa>=3.33){
             if(semester==2 || semester==3)
             {
                Schloarship=(3*PG_INCIDENTAL_FEE *3)/2 ;
             }
             else
             {
               if(noOfPrequite==0)
               {
                  Schloarship=(3*PG_INCIDENTAL_FEE *2)/2 ; 
               }
               else
               {
                 Schloarship=(3*PG_INCIDENTAL_FEE *3)/2 ;  
               }
             }
            }
       
         }
       return Schloarship;
   }
    /**
     * This method calculates total scholarship  for the 4 sem using for for loop
     * @param semester//semester no is stored
     * @param noOfPrequite//prerequisite are stored
     * @param gpa //Gpa is stored
     * @return totalSchloarship
     */
   
   private double calcTotalScholarship(int semester, int noOfPrequite, double gpa)
   {
    double totalSchloarship=0.0;
        for(int i=1;i<=semester;i++)
            {
                 totalSchloarship=totalSchloarship + calcScholarship(i, noOfPrequite, gpa);
            }
        return totalSchloarship;
   }
   
    /**
     *This method calculates semester cost respectively
     * @param semester takes semester value
     * @param noOfPrequite takes prerequisite no 
     * @param gpa takes gpa score
     * @return TotalSemCost
     */
    public double calcSemCost (int semester, int noOfPrequite, double gpa)
   {
      double TotalSemCost=0.0;
      switch(semester)
      {
          case 1:
              TotalSemCost=( calcPrereqCost(noOfPrequite) +
                      (calcReqCourseCostForOneCourse() * findReqCoursesForSem1(noOfPrequite))) +
                       PG_SEM1_INS + PG_ISA_FEE + PG_ORIENTATION_FEE - calcScholarship(semester,noOfPrequite,gpa);/*calculation of the sem1*/
                break;
          case 2:
                
                TotalSemCost=( calcReqCourseCostForOneCourse() * 3) +
                      PG_SEM2_INS + PG_ISA_FEE -calcScholarship(semester,noOfPrequite,gpa);/* calcualtion of the sem2*/ 
                break;
          case 3:
              TotalSemCost= (calcReqCourseCostForOneCourse() * 3) +
                      +PG_ISA_FEE -calcScholarship(semester,noOfPrequite,gpa);/*calculation of the sem3*/
                break;
          case 4:
              if(noOfPrequite==1||noOfPrequite==2)
              {
                  TotalSemCost=(calcReqCourseCostForOneCourse()* 3)+
                                 PG_SEM4_INS+PG_ISA_FEE -calcScholarship(semester,noOfPrequite,gpa); /*calculation of the sem4 with courses 3*/
              }
              else
              {
                TotalSemCost=(calcReqCourseCostForOneCourse()* 2)+
                                 PG_SEM4_INS+PG_ISA_FEE             /*calculation of the sem4 with courses 2*/
                          -calcScholarship(semester,noOfPrequite,gpa);   
              }
         
              break;
          default:
              break;
        }
         return TotalSemCost; 
   
    }

    /**
     *This method calculates the total cost of the all semesters
     * @param semester takes semester no
     * @param noOfPrequite takes prequite no
     * @param gpa//takes gpa value
     * @return totalCost
     */
    public double calcTotalCost(int semester, int noOfPrequite , double gpa){
     double totalCost=0.0;
     
        for (int i=1;i<=semester;i++)
        {
            
             totalCost = totalCost + calcSemCost(i, noOfPrequite, gpa);
        }
        return totalCost;
     }  

    /**
     *This method converts dollars to the rupees 64.55
     * @param totalCost calculates totalcost which stores rupee
     * @return totalINR
     */
    public  double exchUSDToINR(double totalCost){
    double totalINR=0.0; 
     totalINR=totalCost * PG_INDIA_RUPEE;
     return totalINR;
             
 }

    /**
     *This method converts dollars into Euros
     * @param costEuro calculates totalcost which stores rupee
     * @return totalEuro
     */
    public  double exchUSDToEuro(double costEuro){
            double  totalEuro=0.00;
            totalEuro=costEuro * PG_UK_EURO ;
            return totalEuro;
 
    }
    /**
     * This method is overridden
     * returns getNameInitials
    **/
    @Override
        public String toString()
        {
             return getNameInitials();
     
        }

    /**
     *This method is used to the print the statement
     * @param semester  takes semester no
     * @param noOfPrequite takes prequite no
     * @param gpa takes gpa value
     */
    public void printReceipt(int semester, int noOfPrequite, double gpa)
        {
           double result1=calcTotalScholarship(semester, noOfPrequite, gpa);
            //System.out.println(""+semester+""+noOfPrequite+""+gpa);
           double result2=calcTotalCost(semester, noOfPrequite, gpa);
            //System.out.println(result1+"     "+result2);
          System.out.printf("%s, on a whole the total scholarship till semester %d"
           + " is: $ %.2f\nTotal fee till semester %d is: $ %.2f\n",
           getNameInitials(),semester,result1,semester,result2);
        
         }
 
}



