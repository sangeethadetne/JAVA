/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feecalculator;

import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class FeeCalculatorDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String condition;
        
        System.out.println("*******************************");
        System.out.println("***Northwest Cost Calculator***");
        System.out.println("*******************************"+"\n");
        Scanner s1 = new Scanner(System.in);
        
        String studentName;
        do{       
            
             
            do
            {
                System.out.print("Please enter the full name (Firstname Lastname): "); 
                studentName = s1.nextLine();
                //f1.setStudentName(studentName);
            } 
            while(studentName.length()==0);
        
                
                System.out.print("Please enter the number of pre-requisites: ");
            
             int noOfPrequite=s1.nextInt();
             s1.nextLine();
             do{
                if(noOfPrequite > 2){
                    System.out.print("You have entered invalid number, please re-enter either 0 or 1 or 2: "); 
                    noOfPrequite = s1.nextInt();
                    s1.nextLine();
                }
            //System.out.println("The calcualted fee for prequiste is"+f1.calcPrereqCost(noOfPrequite));
            }while(noOfPrequite>2);
        
            //System.out.println("The courses taken : "+f1.findReqCoursesForSem1(noOfPrequite));
            System.out.print("Please enter the number of semesters you want to calculate the cumulative fee: ");
            int noOfSem=s1.nextInt();
            s1.nextLine();
             do
             {
                if(noOfSem>4 || noOfSem<1){
                    System.out.print("You have entered invalid number, please re-enter either 1 or 2 or 3 or 4: ");
                    noOfSem=s1.nextInt();
                    s1.nextLine();
                    
                   }
               }while(noOfSem>4 || noOfSem<1);
         double gpa=0.0;
         if( noOfSem==2|| noOfSem==3 ||noOfSem==4)
         {
             System.out.print("Enter the cumulative GPA: " );
             gpa=s1.nextDouble();
            s1.nextLine();
             do
              {
                  
                  
                     if(gpa>4.00 || gpa<1.00)
                        {
                            System.out.print("The GPA value should be in between 0 and 4, please re-enter: " );
                            gpa=s1.nextDouble();
                            s1.nextLine();
                            
                        }
                  
              }while(gpa>4.00 || gpa<1.00);
         }
         System.out.println();
             System.out.println("****************************************");
             FeeCalculator f1=new FeeCalculator(studentName);
             System.out.println("* Hello, "+f1.getNameInitials());
             System.out.println("*------------------------------------");
             System.out.println("* Your Account Summary");
             System.out.println("*------------------------------------");
             System.out.println("*__________________________________");
            for(int i=1;i<=noOfSem;i++)                                    
             {
                System.out.printf("* Semester "+i+" fee is:    $ %.2f * ",f1.calcSemCost(i, noOfPrequite, gpa));
                System.out.println("");
             }
                System.out.println("*----------------------------------    ");
                System.out.printf("* Total cost:           $ %.2f",f1.calcTotalCost(noOfSem, noOfPrequite, gpa));
                System.out.println("");
                System.out.println("*----------------------------------    ");
                System.out.println("*");
                //System.out.println("Prereq cost:" +f1.calcPrereqCost(noOfPrequite));
                 //System.out.println("Req course cost: "+f1.calcReqCourseCostForOneCourse());
                 //System.out.println("Scholarshp: "+f1.calcScholarship(1, noOfPrequite, gpa));
                double totalCost = f1.calcTotalCost(noOfSem, noOfPrequite, gpa);
                System.out.printf("* USD to INR: Rs. %.2f",f1.exchUSDToINR(totalCost));
                System.out.println("");
                System.out.printf("* USD to Euro: € %.2f",f1.exchUSDToEuro(totalCost));
                System.out.println("");
                System.out.println("****************************************");
                //System.out.println(f1.toString());
               
                f1.printReceipt(noOfSem,noOfPrequite,gpa);
                System.out.print("\nDo you want to calculate again?(Y/N): ");
                condition=s1.nextLine();
                System.out.println("");
                }while("y".equals(condition)||"Y".equals(condition));
        System.out.print("Thank You! All the best.");
        }
      }
         


