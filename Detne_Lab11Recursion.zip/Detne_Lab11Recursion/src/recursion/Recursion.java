/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class Recursion {

    int oddNumber = 0;
    //int oddNumber2 = 0;
    int j = 1;
    boolean flag2 = false;
    int count = 1;

    public int sumOfOdd(int n) {
        if (n < 1) {
            return 1;
        }
        if (n % 2 != 0) {
            oddNumber = oddNumber + n;
        }
        sumOfOdd(n - 1);
        return oddNumber;
    }

    private String name;
    int p = 0;
    int y = 0;
    boolean flag = false;
    private static ArrayList<ArrayList<Student>> argment = new ArrayList<ArrayList<Student>>();

    public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList, int p) {

        ArrayList<Student> listOfStudent = new ArrayList<Student>();

        if (p == studentList.size()) {
            for (int i = 0; i < studentList.size(); i++) {
                listOfStudent.add(studentList.get(i));
            }
            if (listOfStudent.size() == studentList.size()) {
                argment.add(listOfStudent);
            }
        } else {
            for (int i = p; i < studentList.size(); i++) {

                Student temp = studentList.get(p);
                studentList.set(p, studentList.get(i));
                studentList.set(i, temp);

                organizeSeats(studentList, p + 1);

                temp = studentList.get(p);
                studentList.set(p, studentList.get(i));
                studentList.set(i, temp);

            }
            p += 1;
        }
        return argment;
    }

    public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList) {
        ArrayList<Student> a;
        ArrayList<Student> d;
        ArrayList<ArrayList<Student>> res1 = new ArrayList<>();
        int sort = 0;
        ArrayList<ArrayList<Student>> res = new ArrayList<>();
        for (Student s : studentList) {
            a = (ArrayList<Student>) studentList.clone();
            Collections.swap(a, 0, sort);
            sort++;
            d = (ArrayList<Student>) a.clone();
            if (a.size() > 2) {
                a.remove(0);
                res = organizeSeats(a);
            }
            if (studentList.size() == 2) {
                res1.add(a);
            }
            if (studentList.size() == 1) {
                res1.add(d);
            }
            if (studentList.size() > 2) {
                for (ArrayList<Student> item : res) {
                    item.add(0, d.get(0));
                    res1.add(item);
                }
                res.clear();
            }
        }
        return res1;
    }

    public ArrayList<ArrayList<Student>> organizeSeats2(ArrayList<Student> studentList) {
        ArrayList<Student> a;
        ArrayList<Student> d;

        ArrayList<ArrayList<Student>> res0 = new ArrayList<>();
        int sort = 0;
        ArrayList<ArrayList<Student>> result = new ArrayList<>();
        for (Student s : studentList) {
            a = (ArrayList<Student>) studentList.clone();
            Collections.swap(a, 0, sort);
            sort++;
            d = (ArrayList<Student>) a.clone();
            if (a.size() > 2) {
                a.remove(0);
                result = organizeSeats(a);
            }
            if (studentList.size() == 2) {
                res0.add(a);
            }
            if (studentList.size() == 1) {
                res0.add(d);
            }
            if (studentList.size() > 2) {
                for (ArrayList<Student> item : result) {
                    item.add(0, d.get(0));

                    res0.add(item);
                }
                result.clear();
            }
        }
        return res0;
    }

    public int evaluateExpression(String str1) {
        int count12 = 0;
        for (int i = 0; i < str1.length(); i++) {
            if (str1.charAt(i) == '(') {
                count12++;
            }
            if (str1.charAt(i) == ')') {
                count12--;
            }

        }
        if (count12 == 0) {
            ArrayList<Integer> in = new ArrayList<>();
            ArrayList<Integer> in1 = new ArrayList<>();
            ArrayList<String> operator = new ArrayList<String>();

            ArrayList<Integer> out = new ArrayList<>();
            if (str1.indexOf(")") == str1.length() - 1 && str1.lastIndexOf("(") == 0 && str1.contains("<")) {
                int a = 0, j = 0, k = 0, oper = 0;
                a = Integer.parseInt(str1.substring(1, str1.indexOf("<")));
                j = Integer.parseInt(str1.substring(str1.indexOf(">") + 1, str1.length() - 1));
                oper = str1.indexOf("<") + 1;

                switch (str1.charAt(oper)) {
                    case '-':
                        k = a - j;
                        break;
                    case '/':
                        k = a / j;
                        break;
                    case '%':
                        k = a % j;
                        break;
                    case '+':
                        k = a + j;
                        break;
                    case '*':
                        k = a * j;
                        break;
                    default:
                        break;
                }
                return k;
            } else {
                for (int i = 0; i <= str1.length() - 1; i++) {
                    if (str1.charAt(i) == '(') {
                        in.add(i);
                        operator.add(str1.substring(i, i + 1));
                        in1.add(i);
                    }
                    if (str1.charAt(i) == '+' || str1.charAt(i) == '-' || str1.charAt(i) == '*' || str1.charAt(i) == '/'
                            || str1.charAt(i) == '%') {
                        if (str1.charAt(i - 1) == ')') {

                            while ((!operator.isEmpty()) && (!operator.get(operator.size() - 1).matches("\\+|-"))
                                    && (!"(".equals(operator.get(operator.size() - 1)))) {

                                int fo = out.remove(out.size() - 1), so = out.remove(out.size() - 1);
                                String q = "(" + so + "<"
                                        + operator.remove(operator.size() - 1) + ">" + fo + ")";

                                out.add(evaluateExpression(q));
                            }
                            operator.add(str1.substring(i, i + 1));
                        }
                    }
                    if (str1.charAt(i) == ')') {
                        if (str1.charAt(i) == ')' && str1.charAt(i - 1) != ')') {
                            String exp = str1.substring(in.get(in.size() - 1) + 1, i);
                            for (int j = exp.length() - 1; j >= 0; j--) {
                                if (exp.substring(j, j + 1).equals("/") || exp.substring(j, j + 1).equals("*")
                                        || exp.substring(j, j + 1).equals("%")
                                        || exp.substring(j, j + 1).equals("+") || exp.substring(j, j + 1).equals("-")) {
                                    if ((exp.substring(j - 1, j).equals("/") || exp.substring(j - 1, j).equals("%")
                                            || exp.substring(j - 1, j).equals("+")
                                            || exp.substring(j - 1, j).equals("-") || exp.substring(j - 1, j).equals("*"))) {
                                        if (exp.charAt(j) == '+' || exp.charAt(j) == '-') {
                                        } else {

                                        }
                                        out.add(Integer.parseInt(exp.substring(j).trim()));
                                        out.add(Integer.parseInt(exp.substring(0, j - 1).trim()));

                                        operator.add("" + exp.charAt(j - 1));
                                        break;
                                    } else {
                                        operator.add("" + exp.charAt(j));
                                        out.add(Integer.parseInt(exp.substring(j + 1, j + 2).trim()));
                                        out.add(Integer.parseInt(exp.substring(0, j).trim()));

                                        break;
                                    }
                                }
                            }
                        }
                        if (str1.charAt(i - 1) != ')') {

                            String s = "(" + out.remove(out.size() - 1) + "<"
                                    + operator.remove(operator.size() - 1) + ">" + out.remove(out.size() - 1) + ")";
                            out.add(evaluateExpression(s));
                            operator.remove(operator.size() - 1);
                            in.remove(in.size() - 1);

                        } else {

                            int L = operator.lastIndexOf("(");
                            int count0 = 0;
                            for (int c = 0; c < L; c++) {
                                String s = operator.get(c);
                                if (s.equals("*") || s.equals("/") || s.equals("-") || s.equals("+") || s.equals("%")) {
                                    count0++;
                                }

                            }

                            while (L != operator.size() - 1) {

                                out.add(evaluateExpression("(" + out.remove(count0) + "<" + operator.remove(L + 1) + ">"
                                                + out.remove(count0) + ")"));
                            }
                            operator.remove(operator.size() - 1);
                            in.remove(in.size() - 1);

                        }

                    }
                }
                while (!operator.isEmpty() && !operator.get(operator.size() - 1).equals("(")) {

                    int fo = out.remove(out.size() - 1), so = out.remove(out.size() - 1);
                    out.add(
                            evaluateExpression(
                                    "(" + so + "<" + operator.remove(operator.size() - 1) + ">"
                                    + fo + ")"));
                }
            }

            return out.remove(out.size() - 1);
        } else {
            System.out.println("Enter valid expression check ) and (");
            return 0;
        }
    }

}
