/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sangeetha Detne
 */
public class RecursionDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Recursion recurs = new Recursion();
        Scanner scr0 = new Scanner(System.in);
        System.out.println("********************  Sum of odd Numbers ******************");
        System.out.println("Enter the number:");
        
        System.out.println("Sum of the odd numbers upto n:" + recurs.sumOfOdd(scr0.nextInt()));

        Scanner scr = new Scanner(System.in);
        System.out.println("Enter the name of the Students whom you want to be arranged : ");
        String s = scr.nextLine();
        ArrayList<Student> q = new ArrayList<>();
        String[] a = s.split(",");
        Student s9 = null;
        for (String listOfNames : a) {
            s9 = new Student(listOfNames);
            q.add(s9);
        }
        Recursion r1 = new Recursion();
        ArrayList<ArrayList<Student>> arrgmnt = r1.organizeSeats(q);
        System.out.println("************** Seating Arrangements *************");
        for (ArrayList<Student> c : arrgmnt) {

            System.out.println(c);
        }

        System.out.println("\n\n*******Two students are not sitting together.***************************");
        Scanner scan1 = new Scanner(System.in);

        System.out.println("Enter names of students who never sit together with comma:");
        String name = scan1.nextLine();
        ArrayList<Student> list = new ArrayList<Student>();
        String[] lists = name.split(",");
        Student c1;

        for (String n : lists) {
            c1 = new Student(n);
            list.add(c1);
        }

        String s1 = list.get(0).getFname();
        String s2 = list.get(1).getFname();

        ArrayList<String> s5 = new ArrayList<String>();
        int t;
        for (ArrayList<Student> studList : arrgmnt) {
            ArrayList<Student> seatList = new ArrayList<Student>();
            seatList.add(studList.get(0));
            for (int i = 1; i < studList.size(); i++) {
                t = i;
                if ((studList.get(i).getFname().trim().equals(s1) && studList.get(--t).getFname().trim().equals(s2))
                        || (studList.get(i).getFname().trim().equals(s2) && studList.get(--t).getFname().trim().equals(s1))) {
                    break;
                } else {
                    seatList.add(studList.get(i));
                }
                if (seatList.size() == studList.size()) {
                    s5.add(seatList + " ");
                }
            }
        }
        for (String strname : s5) {
            System.out.print(strname.replace('[', ' ').replace(']', ' ').trim());
            System.out.print("\n");
        }
        Scanner scr2 = new Scanner(System.in);
        System.out.println("Enter the expression to evaluate with braces :");
        try {
            System.out.println("Result of the Expresssion: " + recurs.evaluateExpression(scr.nextLine()));
        } catch (ArithmeticException e) {
            System.out.println("Number is divide by zero!!!");
        }
    }

}
